export const environment = {
  production: true,
  baseUrl: 'https://ponyracer.ninja-squad.com',
  wsBaseUrl: 'wss://ponyracer.ninja-squad.com'
};