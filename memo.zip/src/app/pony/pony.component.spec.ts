import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PonyModel } from '../models/pony.model';

import { PonyComponent } from './pony.component';

/*
describe('Pony', () => {
  let pony: PonyComponent;
  beforeEach(() => {
  pony = new PonyComponent('Rainbow Dash', 10);
  });
  it('should have a name', () => {
  expect(pony.name).toBe('Rainbow Dash');
  });
  it('should have a speed', () => {
  expect(pony.speed).not.toBe(1);
  expect(pony.speed).toBeGreaterThan(9);
  });
  });
*/
describe('PonyComponent', () => {
  let component: PonyComponent;
  let fixture: ComponentFixture<PonyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PonyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PonyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
