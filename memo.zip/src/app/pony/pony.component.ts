import { Component, EventEmitter, Input, Output } from '@angular/core';

import { PonyModel } from '../models/pony.model';
import { RaceService } from '../services/race.service';

@Component({
  selector: 'pr-pony',
  templateUrl: './pony.component.html',
  styleUrls: ['./pony.component.css']
})
export class PonyComponent { 
  @Input() ponyModel: PonyModel;
  @Input() isRunning: boolean;
  @Input() isBoosted: boolean;
  @Output() readonly ponyClicked = new EventEmitter<PonyModel>();
  
   //constructor(public pont: RaceService) {}
  
  getPonyImageUrl(): string {
    return `assets/images/pony-${this.ponyModel.color.toLowerCase()}${this.isBoosted ? '-rainbow' : this.isRunning ? '-running' : ''}.gif`;
  }

  clicked(): void {
    this.ponyClicked.emit(this.ponyModel);
  }
/*
  isFasterThan(speed: number): boolean {
    return this.speed > speed;
  }
*/
}