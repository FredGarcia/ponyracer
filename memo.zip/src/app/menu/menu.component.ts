import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { concat, EMPTY, Observable, of, pipe, Subscription } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';

import { UserModel } from '../models/user.model';
import { UserService } from '../services/user.service';
import { WsService } from '../services/ws.service';

@Component({
  selector: 'pr-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})

export class MenuComponent implements OnInit, OnDestroy {
  navbarCollapsed = true;

  user: UserModel;
  userEventsSubscription: Subscription;


  constructor(private userService: UserService, private router: Router, private route: ActivatedRoute, private wsService: WsService) {}

  ngOnInit(): void {
    console.log("MENU ngOninit");
    // this.userEventsSubscription = this.userService.userEvents.subscribe(user => this.user =user);
    this.userEventsSubscription = this.userService.userEvents
    .pipe(switchMap(user => (user ? concat(of(user), this.userService.scoreUpdates(user.id)
    .pipe(catchError(() => EMPTY))) : of(null))))
    .subscribe((userWithScore: UserModel) => this.user = userWithScore);
  }

  ngOnDestroy(): void {
    if (this.userEventsSubscription) {
      this.userEventsSubscription.unsubscribe();
    }
  }

  toggleNavbar(evt): void {
    this.navbarCollapsed = !this.navbarCollapsed;
    console.log(JSON.stringify(evt));
  }

  logout(event){
    event.preventDefault();
    this.userService.logout();
    this.router.navigate(['/']);
  }

}