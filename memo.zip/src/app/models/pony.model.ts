export interface PonyModel {
  id: number;
  name: string;
  color: string;
  speed: number;
}

export interface PonyWithPositionModel extends PonyModel {
  position: number;
  boosted?: boolean;
}