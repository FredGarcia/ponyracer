import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpContextToken
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserService } from '../services/user.service';

@Injectable({
  providedIn: 'root'
})

export class JwtInterceptor implements HttpInterceptor {

  token:string
  cpt: number = 0;
  constructor() {
    console.log("Jwt Token construct: " + this.token);
  }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
/*
export const SHOULD_NOT_HANDLE_ERROR = new HttpContextToken<boolean>(() => false);
    if (req.context.get(SHOULD_NOT_HANDLE_ERROR)) {
      return next.handle(req);
      }
      return next.handle(req).pipe(
      // we catch the error
      catchError((errorResponse: HttpErrorResponse) => {
      }));
*/
    if (this.token) {
      // CLONE SI UN TOKEN EXIST
      console.log("Jwt token intercept: " + this.token);
      const clone =
        request.clone({ setHeaders: { Authorization: `Bearer ${this.token}` } });
        console.log("this token : " + this.token);
      return next.handle(clone);
    }
    console.log("request: " + JSON.stringify(request));
    return next.handle(request);
  }
 
  setJwtToken(token: string): void {
    console.log("Token : " + this.cpt++ + " passages");
    this.token = token;
  }

  removeJwtToken(): void {
    this.token = null;
  }
}