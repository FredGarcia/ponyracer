import { Component, OnInit } from '@angular/core';
// import { ReactiveFormsModule, FormsModule, FormControl, FormGroup, FormBuilder} from '@angular/forms';
import { RouterLinkActive } from '@angular/router';
import { UserModel } from '../models/user.model';

import { UserService } from '../services/user.service';
@Component({
  selector: 'pr-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  user: UserModel;
 // routerLinkActive: RouterLinkActive;

  constructor(private userService: UserService) { 
 //   console.log("Home homeService:");
  }

  ngOnInit(){
    this.user = JSON.parse(window.localStorage.getItem('ponyraceId'));
  }

  logout(){
    event.preventDefault();
    this.userService.logout();

  }
/*
  isConnected(): boolean {
  //  console.log("Home Connection");
    let isconnected = this.userService.isLoggedIn();
  //  console.log("Home Connecté ? " + isconnected);
    return isconnected;
  }*/
}
