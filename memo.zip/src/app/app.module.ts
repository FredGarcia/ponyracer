import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule, FormControl, FormGroup, FormBuilder} from '@angular/forms';

import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { RacesComponent } from './races/races.component';
import { RaceComponent } from './race/race.component';
import { PonyComponent } from './pony/pony.component';
import { FromNowPipe } from './pipes/from-now.pipe';

import { RouterModule } from '@angular/router';
//import { NgModule } from '@angular/core';
//import { BrowserModule } from '@angular/platform-browser';
//import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { PreloadAllModules/*, RouterModule*/ } from '@angular/router';

import { ROUTES } from './app.routes';
//import { AppComponent } from './app.component';
//import { MenuComponent } from './menu/menu.component';
import { HomeComponent } from './home/home.component';
import { JwtInterceptor } from './interceptors/jwt.interceptor';

@NgModule({
  declarations: [AppComponent, MenuComponent, HomeComponent],
  imports: [BrowserModule, HttpClientModule, RouterModule.forRoot(ROUTES, { preloadingStrategy: PreloadAllModules })],
  providers: [{ provide: HTTP_INTERCEPTORS, useExisting: JwtInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule {}




/*import { ROUTES } from './app.routes';
import { HomeComponent } from './home/home.component';
import { TranslatePipe } from './pipes/translate.pipe';

import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { JwtInterceptor } from './interceptors/jwt.interceptor';
import { LoggedInGuard } from './guars/loggedin.guard';
import { BetComponent } from './bet/bet.component';
import { LiveComponent } from './live/live.component';
import { PendingRacesComponent } from './races/pending-races/pending-races.component';
import { FinishedRacesComponent } from './races/finished-races/finished-races.component';
import { RaceResolver } from './resolvers/race.resolver';
import { RacesResolver } from './resolvers/races.resolver';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';


@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    HomeComponent,    
    RacesComponent,
    RaceComponent,
    PonyComponent,
    FromNowPipe,
    TranslatePipe,
    RegisterComponent,    
    LoginComponent,
    BetComponent,
    LiveComponent,
    PendingRacesComponent,
    FinishedRacesComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule, FormsModule, ReactiveFormsModule,
    RouterModule.forRoot(ROUTES),
    NgbModule,
    FontAwesomeModule    
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useExisting: JwtInterceptor, multi: true }, LoggedInGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
*/