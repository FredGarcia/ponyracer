import { Component, Input } from '@angular/core';
import { PonyModel } from '../models/pony.model';

import { RaceModel } from '../models/race.model';
import { FromNowPipe } from '../pipes/from-now.pipe';
import { TranslatePipe } from '../pipes/translate.pipe';

@Component({
  selector: 'pr-race',
  templateUrl: './race.component.html',
  styleUrls: ['./race.component.css']
})
export class RaceComponent {
  @Input() raceModel: RaceModel;
  formNow = new FromNowPipe();
  translate = new TranslatePipe();
  ponyDetail: PonyModel

  detailPony(pony):void {
    console.log('PONEY CLICKED')
    this.ponyDetail = pony
  }
}