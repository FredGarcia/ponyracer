import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FinishedRacesComponent } from './finished-races/finished-races.component';
import { PendingRacesComponent } from './pending-races/pending-races.component';
import { LiveComponent } from '../live/live.component';
import { BetComponent } from '../bet/bet.component';
import { FromNowPipe } from '../pipes/from-now.pipe';
import { PonyComponent } from '../pony/pony.component';
import { RaceComponent } from '../race/race.component';
import { RacesComponent } from './races.component';
import { RouterModule } from '@angular/router';
import { RACES_ROUTES } from './races.routes';
import { TranslatePipe } from '../pipes/translate.pipe';

@NgModule({
  imports: [CommonModule, RouterModule.forChild(RACES_ROUTES)],
  declarations: [
    RacesComponent,
    RaceComponent,
    PonyComponent,
    FromNowPipe,
    TranslatePipe,
    BetComponent,
    LiveComponent,
    PendingRacesComponent,
    FinishedRacesComponent
  ]
})
export class RacesModule {}
